function profileInit() {
    currentPage = "PROFILE";
    
    
}